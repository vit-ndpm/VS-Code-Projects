<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e($data['title']); ?></title>
    <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
</head>
<body>
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Online Exam System Narmdaapuram</h5>
            <p class="card-body">
                
                <h3>Password Reset Request</h3>
                <p>Kinldy click on below link to reset your password <br>
                    <a class="btn btn-success" href="<?php echo e($data['url']); ?>">Reset Password</a>
                </p>
                <pre>
                    Thanks and Regards <br>
                    Support <br>
                    Online Exam System Narmdapuram MP
                </pre>
        </div>
    </div>
    
    
</body>
</html><?php /**PATH C:\Program Files\Ampps\www\Laravel Projects\OnlineExam\resources\views/API/forgetPassword.blade.php ENDPATH**/ ?>