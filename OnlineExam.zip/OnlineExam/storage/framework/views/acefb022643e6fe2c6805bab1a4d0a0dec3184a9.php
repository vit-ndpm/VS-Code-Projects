<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Question List')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <div class="py-12 ">
        <div class="max-w-11xl mx-auto sm:px-6 lg:px-8 overflow-auto" >
            <div class="bg-white  shadow-sm sm:rounded-lg ">
                
                <?php if(Session::has('status')): ?>
                    <div class="alert alert-success">
                        <ul>
                            <li><?php echo Session::get('status'); ?></li>
                        </ul>
                    </div>
                <?php endif; ?>
                <div class="p-6 bg-white border-b  border-gray-200">
                    
                    <a class="btn btn-success my-2" href="<?php echo e(url('addQuestion')); ?>/<?php echo e($paper_id); ?>"> Add New
                        Question</a>
                    <a class="btn btn-primary my-2" href="<?php echo e(url('showw')); ?>"> Import Data from Excel Sheet</a>
                    <a class="btn btn-warning my-2" href="<?php echo e(url('#')); ?>"> Export Data in Excel Sheet</a>
                    
                    <?php if(isset($questions)): ?>
                    <div class="overflow:hidden">
                        <table class="table table-bordered w-100">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Paper Name </th>
                                    <th>Question No</th>
                                    <th>Question?</th>
                                    <th>Option-1</th>
                                    <th>Option-2</th>
                                    <th>Option-3</th>
                                    <th>Option-4</th>
                                    <th>Answer</th>
                                    <th>Description</th>
                                    <th>Subject</th>
                                    <th>Topic</th>
                                    <th>Edit</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($question->id); ?></td>
                                        <td><?php echo e($question->paper_id); ?></td>
                                        <td><?php echo e($question->question_no); ?></td>
                                        <td><?php echo e($question->question); ?></td>
                                        <td><?php echo e($question->option1); ?></td>
                                        <td><?php echo e($question->option2); ?></td>
                                        <td><?php echo e($question->option3); ?></td>
                                        <td><?php echo e($question->option4); ?></td>
                                        <td><?php echo e($question->correct_option); ?></td>
                                        <td><?php echo e($question->description); ?></td>
                                        <td><?php echo e($question->subject); ?></td>
                                        <td><?php echo e($question->topic); ?></td>
                                        <td>
                                            <a href="<?php echo e(url('editQuestion')); ?>/<?php echo e($question->id); ?>">
                                                <i class="fa-solid fa-pen-to-square text-primary"></i>
                                            </a>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(url('deleteQuestion')); ?>/<?php echo e($question->id); ?>">
                                                <i class="fa-solid fa-trash text-danger"></i>
                                            </a>
                                        </td>

                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Program Files\Ampps\www\Laravel Projects\OnlineExam\resources\views/admin/questions/questionList.blade.php ENDPATH**/ ?>