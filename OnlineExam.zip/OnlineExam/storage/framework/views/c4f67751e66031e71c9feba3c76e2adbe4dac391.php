<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-900 leading-tight">
            <?php echo e(__(' Admin Dashboard (District e-Governance Society Narmadapuram MP)')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <div class="container-fluide vh-100" style="background-image: url('img/background.png')">
        <div class="row py-3 mx-3">

            
            <div class="col-10 ">
                <div class="row py-3 mx-1 bg-white text-dark card">
                    <div class="col">
                        main content
                    </div>
                </div>
            </div>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Program Files\Ampps\www\Laravel Projects\OnlineExam\resources\views/adminDashboard.blade.php ENDPATH**/ ?>