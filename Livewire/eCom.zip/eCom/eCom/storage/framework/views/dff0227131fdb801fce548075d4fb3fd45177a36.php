<div class="d-inline">
    <?php echo e($cartCount); ?>

</div>
<?php /**PATH C:\Program Files\Ampps\www\Laravel Projects\Livewire\eCom\eCom\resources\views/livewire/frontend/cart/cart-count.blade.php ENDPATH**/ ?>