
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <?php if(Session::has('message')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(Session::get('message')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <div class="card">
                <div class="card-header">
                    <h3>Products</h3>
                    <a href="<?php echo e(url('admin/product/create')); ?>" class="btn btn-success text-light float-end">Add Product</a>
                </div>
                <div class="card-body">
                    <div class="shadow p-1">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>
                                        ID
                                    </th>
                                    <th>
                                        Category
                                    </th>
                                    <th>
                                        Product
                                    </th>
                                    <th>
                                        Brand
                                    </th>
                                    <th>
                                        Price
                                    </th>
                                    <th>
                                        Quantity
                                    </th>
                                    <th>
                                        Status
                                    </th>
                                    <th>
                                        Actions
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($product->id); ?></td>
                                        <td>
                                            <?php if($product->category): ?>
                                                <?php echo e($product->category->name); ?>

                                            <?php else: ?>
                                                No Category
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($product->name); ?></td>
                                        <td><?php echo e($product->brand); ?></td>
                                        <td><?php echo e($product->original_price); ?></td>
                                        <td><?php echo e($product->quantity); ?></td>
                                        <td><?php echo e($product->status == true ? 'visible' : 'hidden'); ?></td>
                                        <td>
                                            <a href="<?php echo e(url('admin/product/' . $product->id.'/edit')); ?>"
                                                class="btn btn-primary btn-sm text-light">Edit</a>
                                            <a href="<?php echo e(url('admin/product/' . $product->id.'/delete')); ?>"
                                               onclick="return confirm('Are you Sure to Delete this Product ?')" class="btn btn-danger btn-sm text-light">Delete</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <td colspan="7">
                                        No Product available
                                    </td>
                                <?php endif; ?>

                            </tbody>
                        </table>
                    </div>


                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Program Files\Ampps\www\Laravel Projects\Livewire\eCom\eCom\resources\views/admin/products/index.blade.php ENDPATH**/ ?>