
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <?php if(Session::has('message')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(Session::get('message')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>
        <div class="card">
            <div class="card-header">
                <h3>Colors</h3>
                <a href="<?php echo e(url('admin/color/create')); ?>" class="btn btn-success text-light float-end">Add Color</a>
            </div>
            <div class="card-body">
                <div class="shadow p-1">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>
                                    ID
                                </th>
                                <th>
                                    Color Name
                                </th>
                                <th>
                                    Color Code
                                </th>
                                <th>
                                    Status
                                </th>

                                <th>
                                    Actions
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($color->id); ?></td>
                                <td><?php echo e($color->name); ?></td>
                                <td><?php echo e($color->code); ?></td>
                                <td><?php echo e($color->status==true ?'hidden':'visible'); ?></td>
                                <td>
                                    <a href="<?php echo e(url('admin/color/' . $color->id.'/edit')); ?>" class="btn btn-primary btn-sm text-light">Edit</a>
                                    <a href="<?php echo e(url('admin/color/' . $color->id.'/delete')); ?>"
                                        onclick="return confirm('Are you Sure to Delete this Color ?')"
                                        class="btn btn-danger btn-sm text-light">Delete</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <td colspan="5">
                                No Colors available
                            </td>
                            <?php endif; ?>

                        </tbody>
                    </table>
                </div>


            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Program Files\Ampps\www\Laravel Projects\Livewire\eCom\eCom\resources\views/admin/colors/index.blade.php ENDPATH**/ ?>