
<?php $__env->startSection('title','Product'); ?>
<?php $__env->startSection('content'); ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.products.view', ['product' => $product,'category' => $category])->html();
} elseif ($_instance->childHasBeenRendered('2MrKLM0')) {
    $componentId = $_instance->getRenderedChildComponentId('2MrKLM0');
    $componentTag = $_instance->getRenderedChildComponentTagName('2MrKLM0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('2MrKLM0');
} else {
    $response = \Livewire\Livewire::mount('frontend.products.view', ['product' => $product,'category' => $category]);
    $html = $response->html();
    $_instance->logRenderedChild('2MrKLM0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Program Files\Ampps\www\Laravel Projects\Livewire\eCom\eCom\resources\views/frontend/collections/products/view.blade.php ENDPATH**/ ?>