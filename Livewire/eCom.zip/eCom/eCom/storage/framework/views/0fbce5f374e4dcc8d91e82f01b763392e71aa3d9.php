
<?php $__env->startSection('title','Product'); ?>
<?php $__env->startSection('content'); ?>

<div class="py-3 py-md-5 bg-light">
    <div class="container">
        <div class="row">
            
            <div class="col-md-9">
                <div class="row">
                    <div class="col-md-12">
                        <h4 class="mb-4">Our Products</h4>
                    </div>
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.products.index', ['category' => $category,'brands' => $brands])->html();
} elseif ($_instance->childHasBeenRendered('dbScs3u')) {
    $componentId = $_instance->getRenderedChildComponentId('dbScs3u');
    $componentTag = $_instance->getRenderedChildComponentTagName('dbScs3u');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('dbScs3u');
} else {
    $response = \Livewire\Livewire::mount('frontend.products.index', ['category' => $category,'brands' => $brands]);
    $html = $response->html();
    $_instance->logRenderedChild('dbScs3u', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Program Files\Ampps\www\Laravel Projects\Livewire\eCom\eCom\resources\views/frontend/collections/products/index.blade.php ENDPATH**/ ?>