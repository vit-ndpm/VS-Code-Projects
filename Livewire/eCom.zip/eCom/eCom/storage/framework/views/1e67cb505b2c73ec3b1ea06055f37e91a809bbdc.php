
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <?php if(Session::has('message')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(Session::get('message')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>
        <div class="card">
            <div class="card-header">
                <h3>Colors</h3>
                <a href="<?php echo e(url('admin/color')); ?>" class="btn btn-success text-light float-end">Back</a>
            </div>
            <div class="card-body">
                <form action="<?php echo e(url('admin/color/'.$color->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="name">Color Name</label>
                        <input type="text" name="name" id="name"  value="<?php echo e($color->name); ?>" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label for="code">Color Code</label>
                        <input type="text" name="code" id="code"  value="<?php echo e($color->code); ?>" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label for="status">Status</label> <br>
                        <input type="checkbox" name="status"  <?php echo e($color->status==true ?'checked':''); ?> style="width: 25px;height:25px;"> checked=Hidden, UnChecked=visible
                    </div>
                    <div class="mb-3">
                        <button type="submit" class="btn btn-dark text-light">Update Color</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Program Files\Ampps\www\Laravel Projects\Livewire\eCom\eCom\resources\views/admin/colors/edit.blade.php ENDPATH**/ ?>