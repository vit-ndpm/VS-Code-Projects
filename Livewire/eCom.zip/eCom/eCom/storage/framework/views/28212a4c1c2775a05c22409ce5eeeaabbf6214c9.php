
<?php $__env->startSection('title', 'Checkout'); ?>
<?php $__env->startSection('content'); ?>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.checkout.checkout-show', [])->html();
} elseif ($_instance->childHasBeenRendered('FozCPX6')) {
    $componentId = $_instance->getRenderedChildComponentId('FozCPX6');
    $componentTag = $_instance->getRenderedChildComponentTagName('FozCPX6');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('FozCPX6');
} else {
    $response = \Livewire\Livewire::mount('frontend.checkout.checkout-show', []);
    $html = $response->html();
    $_instance->logRenderedChild('FozCPX6', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Program Files\Ampps\www\Laravel Projects\Livewire\eCom\eCom\resources\views/frontend/checkout/index.blade.php ENDPATH**/ ?>