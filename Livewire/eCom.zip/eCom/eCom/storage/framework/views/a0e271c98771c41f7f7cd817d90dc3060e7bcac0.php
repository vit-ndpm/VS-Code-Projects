<div>
    
    <?php echo $__env->make('livewire.admin.brand.modalForm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('livewire.admin.brand.modalEditBrand', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('livewire.admin.brand.modalDeleteBrand', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">
        <?php if(Session::has('message')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(Session::get('message')); ?>

                 
            </div>
        <?php endif; ?>
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3>Brands</h3>
                    <a href="#" class="btn btn-sm btn-success text-light float-end" data-bs-toggle="modal"
                        data-bs-target="#addBrandModal">Add New Brand</a>
                </div>
                <div class="card-body">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>
                                    id
                                </th>
                                <th>
                                    Category ID
                                </th>
                                <th>
                                    name
                                </th>
                                <th>
                                    slug
                                </th>
                                <th>
                                    status
                                </th>
                                <th>
                                    Action
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(isset($brands)): ?>
                                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <?php echo e($brand->id); ?>

                                        </td>
                                        <td>
                                            <?php if($brand->category): ?>
                                            <?php echo e($brand->category->name); ?>

                                            <?php endif; ?>
                                            
                                        </td>
                                        <td>
                                            <?php echo e($brand->name); ?>

                                        </td>
                                        <td>
                                            <?php echo e($brand->slug); ?>

                                        </td>
                                        <td>
                                            <?php echo e($brand->status == 1 ?'hidden' : 'visible'); ?>

                                        </td>
                                        <td>
                                            <a href="#" wire:click='editBrand(<?php echo e($brand->id); ?>)'
                                                class="btn btn-sm btn-primary text-light" data-bs-toggle="modal"
                                                data-bs-target="#editBrandModal">Edit</a>
                                            <a href="#" wire:click='deleteBrand(<?php echo e($brand->id); ?>)'
                                                class="btn btn-sm btn-danger text-light" data-bs-toggle="modal"
                                                data-bs-target="#deleteBrandModal">Delete</a>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

                        </tbody>
                    </table>
                    <div> <?php echo e($brands->links()); ?>

                    </div>

                </div>
            </div>
        </div>
    </div>

</div>
<?php $__env->startPush('script'); ?>
    <script>
        window.addEventListener('close-modal', event => {
            $('#addBrandModal').modal('hide');
            $('#editBrandModal').modal('hide');
            $('#deleteBrandModal').modal('hide');

        });
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\Program Files\Ampps\www\Laravel Projects\Livewire\eCom\eCom\resources\views/livewire/admin/brand/brand-compo.blade.php ENDPATH**/ ?>