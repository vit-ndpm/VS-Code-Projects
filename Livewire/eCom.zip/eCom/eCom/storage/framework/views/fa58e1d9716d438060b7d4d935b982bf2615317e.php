
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <?php if(Session::has('message')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(Session::get('message')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <div class="card">
                <div class="card-header">
                    <h3>Category</h3>
                    <a href="<?php echo e(url('admin/category/create')); ?>" class="btn btn-success float-end">Add Category</a>
                </div>
                <div class="card-body">
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.category.category-componet')->html();
} elseif ($_instance->childHasBeenRendered('6LKPDTe')) {
    $componentId = $_instance->getRenderedChildComponentId('6LKPDTe');
    $componentTag = $_instance->getRenderedChildComponentTagName('6LKPDTe');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('6LKPDTe');
} else {
    $response = \Livewire\Livewire::mount('admin.category.category-componet');
    $html = $response->html();
    $_instance->logRenderedChild('6LKPDTe', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Program Files\Ampps\www\Laravel Projects\Livewire\eCom\eCom\resources\views/admin/category/index.blade.php ENDPATH**/ ?>