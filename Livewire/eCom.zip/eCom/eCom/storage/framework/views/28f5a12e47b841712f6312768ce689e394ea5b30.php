
<?php $__env->startSection('content'); ?>
<div class="row">
    <?php if($errors->any()): ?>
    <?php echo e(implode('', $errors->all('<div>:message</div>'))); ?>

    <?php endif; ?>
    <div class="col-md-12">
        <?php if(Session('message')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(Session('message')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>
        <div class="card">
            <div class="card-header">
                <h3>Edit Products</h3>
                <a href="<?php echo e(url('admin/product/')); ?>" class="btn btn-success text-light float-end">Back</a>
            </div>
            <form action="<?php echo e(url('admin/product/'.$product->id)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="card-body">

                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home"
                                type="button" role="tab" aria-controls="home" aria-selected="true">Home</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="seo-tags" data-bs-toggle="tab" data-bs-target="#seo"
                                type="button" role="tab" aria-controls="seo" aria-selected="false">SEO
                                Tags</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="price-tab" data-bs-toggle="tab" data-bs-target="#price"
                                type="button" role="tab" aria-controls="price" aria-selected="false">Price and
                                Other
                                Details</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="image-tab" data-bs-toggle="tab" data-bs-target="#image"
                                type="button" role="tab" aria-controls="image" aria-selected="false">Images</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="image-tab" data-bs-toggle="tab" data-bs-target="#colors"
                                type="button" role="tab" aria-controls="colors" aria-selected="false">Colors</button>
                        </li>
                    </ul>
                    <div class="tab-content" id="myTabContent">
                        <div class="tab-pane border  card shadow p-3 fade show active" id="home" role="tabpanel"
                            aria-labelledby="home-tab">
                            <div class="mb-3 mt-3">
                                <label for="">Select Category</label>
                                <select name="category_id" id="" class="form-control">
                                    <?php if(isset($categories)): ?>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>" <?php echo e($category->id == $product->category_id ?
                                        'selected' : ''); ?>>
                                        <?php echo e($category->name); ?> </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>
                                <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3">
                                <label for="">Select Brand</label>
                                <select name="brand" id="" class="form-control">
                                    <?php if(isset($brands)): ?>
                                    <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($brand->name); ?>" <?php echo e($brand->name == $product->brand ? 'selected' :
                                        ''); ?>><?php echo e($brand->name); ?>

                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>
                                <?php $__errorArgs = ['brand'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3">
                                <label for="slug">Slug</label>
                                <input type="text" name="slug" id="" class="form-control" value="<?php echo e($product->slug); ?>">
                                <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3">
                                <label for="name">Product Name</label>
                                <input type="text" name="name" id="" class="form-control" value="<?php echo e($product->name); ?>">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3">
                                <label for="small_description">Short Product Description</label>
                                <textarea name="small_description" id="" rows="3" class="form-control">
                                        <?php echo e($product->small_description); ?>                               
                                </textarea>
                                <?php $__errorArgs = ['small_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3">
                                <label for="long_description">Long Product Description</label>
                                <textarea name="long_description" id="" rows="3" class="form-control">
                                        <?php echo e($product->long_description); ?>    

                                </textarea>
                                <?php $__errorArgs = ['long_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                        </div>
                        <div class="tab-pane border  card shadow p-3 fade" id="seo" role="tabpanel"
                            aria-labelledby="seo-tags">
                            <div class="mb-3">
                                <label for="meta_title">meta_title</label>
                                <input type="text" name="meta_title" id="" class="form-control"
                                    value="<?php echo e($product->meta_title); ?>">
                                <?php $__errorArgs = ['meta_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3">
                                <label for="meta_keywords">meta_keywords</label>
                                <textarea name="meta_keywords" id="" rows="3" class="form-control">
                                        <?php echo e($product->meta_keywords); ?>                     
                            </textarea>
                                <?php $__errorArgs = ['meta_keywords'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3">
                                <label for="meta_description">meta_description</label>
                                <textarea name="meta_description" id="" rows="3" class="form-control">
                                        <?php echo e($product->meta_description); ?>

                            </textarea>
                                <?php $__errorArgs = ['meta_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="tab-pane border  card shadow p-3 fade" id="price" role="tabpanel"
                            aria-labelledby="price-tab">
                            <div class="mb-3">
                                <label for="original_price">Original Price</label>
                                <input type="text" name="original_price" id="" class="form-control"
                                    value="<?php echo e($product->original_price); ?>">
                                <?php $__errorArgs = ['original_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3">
                                <label for="selling_price">Selling Price</label>
                                <input type="text" name="selling_price" id="" class="form-control"
                                    value="<?php echo e($product->selling_price); ?>">
                                <?php $__errorArgs = ['selling_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3">
                                <label for="quantity">Quantity</label>
                                <input type="text" name="quantity" id="" class="form-control"
                                    value="<?php echo e($product->quantity); ?>">
                                <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3">
                                <label for="status">Status</label>
                                <input type="checkbox" name="status" <?php echo e($product->status == 1 ? 'checked' : ''); ?>>
                                Checked=Hidden , Unchecked=Visible
                            </div>
                            <div class="mb-3">
                                <label for="trending">Status</label>
                                <input type="checkbox" name="trending" <?php echo e($product->trending == 1 ? 'checked' : ''); ?>>
                                Checked=Trending , Unchecked=not Trending
                                <?php $__errorArgs = ['trending'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                        </div>
                        <div class="tab-pane border  card shadow p-3 fade" id="image" role="tabpanel"
                            aria-labelledby="image-tab">

                            <div class="my-3">
                                <label for="image">Upload Product Images</label>
                                <input type="file" name="image[]" multiple class="form-control">
                                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div>

                                <div class="row">
                                    <?php $__empty_1 = true; $__currentLoopData = $product->productImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div class="col-md-1 m-1 p-1 card">

                                        <img class="shadow" src="<?php echo e(asset($image->image)); ?>" alt="" height="80px"
                                            width="80px">
                                        <a href="<?php echo e(url('admin/product/'.$image->id.'/remove')); ?>"
                                            class="d-block text-danger">Remove</a>

                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    no images found for this product
                                    <?php endif; ?>
                                </div>


                            </div>
                        </div>
                        <div class="tab-pane border  card shadow p-3 fade" id="colors" role="tabpanel"
                            aria-labelledby="colors-tab">

                            <label for="color">Select Colors and Quantity</label>
                            <div class="row">
                                <?php if(isset($colors)): ?>
                                <?php $__empty_1 = true; $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="col-md-2">
                                    <div class="border p-2 m-2 shadow">
                                        Color:<input class="mb-3 form-check-input " type="checkbox" name="colors[]"
                                            value="<?php echo e($color->id); ?>" style="width: 20px; height:20px;"><?php echo e($color->name); ?>

                                        <br>
                                        <label for="colorquantity">Quantity:</label>
                                        <input type="number" name="colorquantity[]"
                                            style="width:80px; height:20px;border:1px solid" class="form-control">
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                No Color Found
                                <?php endif; ?>
                                <?php endif; ?>
                            </div>
                            <div class="my-3 table-responsive">
                                <table class="table table-bordered table-hover table-sm">
                                    <thead>
                                        <tr>
                                            <th>
                                                Color Name
                                            </th>
                                            <th>
                                                Quantity
                                            </th>

                                            <th>
                                                delete
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if(isset($product->productColors)): ?>
                                        <?php $__empty_1 = true; $__currentLoopData = $product->productColors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productColor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr class="prodColorTr">
                                            <td>
                                                <?php echo e($productColor->color->name); ?>

                                            </td>
                                            <td>
                                                <div class="input-group">
                                                    <input type="number" value="<?php echo e($productColor->quantity); ?>"
                                                        class="input-control text-center prodColorQty"
                                                        style="width: 70px;">
                                                    <button type="button" value="<?php echo e($productColor->id); ?>"
                                                        class="updateProdColor btn btn-primary text-light">Update</button>
                                                </div>
                                            </td>
                                            <td>
                                                <a href="<?php echo e(url('admin/productColorQty/'.$productColor->id.'/remove')); ?>"
                                                    class="btn btn-danger text-light">Remove</a>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="3">No Color Found</td>
                                        </tr>
                                        <?php endif; ?>


                                        <?php endif; ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="my-3 py-2">
                        <button type="submit" class="text-light btn btn-primary float-end">
                            Update Product
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function () {
        $.ajaxSetup({
             headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});
        $(document).on('click','.updateProdColor',function () {
            var prodId=<?php echo e($product->id); ?>;
            var prodColorId=this.value;
            var qty=$(this).closest('.prodColorTr').find('.prodColorQty').val();
            if(qty<=0){
                alert('Quantity is required');
                return false;
            }
            var data={
                'prodId':prodId,
                'qty':qty
            }
            $.ajax({
                type: "POST",
                url: "/admin/product-color/"+prodColorId,
                data: data,
                success: function (response) {
                    alert(response.message);
                }
            });
        });
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Program Files\Ampps\www\Laravel Projects\Livewire\eCom\eCom\resources\views/admin/products/edit.blade.php ENDPATH**/ ?>