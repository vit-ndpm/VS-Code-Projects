<div>
    
    <div class="table-responsive">
        <table class=" table table-sm  table-responsive table-bordered table-hover">
            <thead>
                <tr>
                    <th>
                        Color Name
                    </th>
                    <th>
                        Quantity
                    </th>
                    
                    <th>
                        delete
                    </th>
                </tr>
            </thead>
            <tbody>
                <?php if(isset($productColors)): ?>
                <?php $__empty_1 = true; $__currentLoopData = $productColors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productColor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td>
                        <?php echo e($productColor->color_id); ?>

                    </td>
                    <td>
                        <div class="input-group">
                       <input wire:model='quantity[]' class="input-control text-center" type="number"  style="width: 70px;"> 
                   
                        <button class="btn text-light btn-primary ">Update</button>
                    </div>
                    </td>
                    <td>
                        <button class="btn text-light btn-danger ">Delete</button>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    
                <?php endif; ?>
                    
                <?php endif; ?>
                
            </tbody>
        </table>
    </div>
</div>
<?php /**PATH C:\Program Files\Ampps\www\Laravel Projects\Livewire\eCom\eCom\resources\views/livewire/prod-color-qty.blade.php ENDPATH**/ ?>