
    
    <div class="d-inline">
        <?php echo e($wishListCount); ?>

    </div>

<?php /**PATH C:\Program Files\Ampps\www\Laravel Projects\Livewire\eCom\eCom\resources\views/livewire/frontend/wishlist/wishlist-count.blade.php ENDPATH**/ ?>