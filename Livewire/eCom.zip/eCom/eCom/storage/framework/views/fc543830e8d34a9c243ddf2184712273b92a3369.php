<div>
    
    <div class="row">

    </div>


    <div class="row">
        <div class="col-md-3">
            <?php if($brands): ?>
            <div class="card">
                <div class="card-header">
                    <h4>Brands</h4>
                </div>
                <div class="card-body">
                    <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-check">
                        <label class="form-check-label">
                            <?php echo e($brand->name); ?>

                        </label>
                        <input wire:model='brandInputs' class="form-check-input" type="checkbox"
                            value="<?php echo e($brand->name); ?>">

                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <?php endif; ?>
            <div class="card my-2">
                <div class="card-header">
                    <h4>Price</h4>
                </div>
                <div class="card-body">
                    <div class="d-block">
                        <input type="radio" wire:model='priceInput' name="priceSort" value="high_to_low">
                        <label for="price">High To Low</label>
                    </div>
                    <div class="d-block">
                        <input type="radio" wire:model='priceInput' name="priceSort" value="low_to_high">
                        <label for="price">Low To High</label>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-9">
            <div class="row">
                <div class="col-md-12">
                    <h4 class="mb-4">Our Products</h4>
                </div>
                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-md-4">
                    <div class="product-card">
                        <div class="product-card-img">
                            <?php if($product->quantity>0): ?>
                            <label class="stock bg-success">In Stock</label>
                            <?php else: ?>
                            <label class="stock bg-danger">out of Stock</label>
                            <?php endif; ?>

                            <?php if($product->productImages->count()>0): ?>
                            <img src="<?php echo e(asset($product->productImages[0]->image)); ?>" alt="Laptop">
                            <?php endif; ?>

                        </div>
                        <div class="product-card-body">
                            <p class="product-brand"><?php echo e($product->brand); ?></p>
                            <h5 class="product-name">
                                <a href="">
                                    <?php echo e($product->name); ?>

                                </a>
                            </h5>
                            <div>
                                <span class="selling-price"> <?php echo e($product->selling_price); ?></span>
                                <span class="original-price"><?php echo e($product->original_price); ?></span>
                            </div>
                            <div class="mt-2">
                                <a href="" class="btn btn1">Add To Cart</a>
                                <a href="" class="btn btn1"> <i class="fa fa-heart"></i> </a>
                                <a href="<?php echo e(url('/collections/product/'.$category->slug.'/'.$product->slug)); ?>" class="btn btn1"> View </a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                No Product available in this category
                <?php endif; ?>


            </div>
        </div>
    </div>
</div><?php /**PATH C:\Program Files\Ampps\www\Laravel Projects\Livewire\eCom\eCom\resources\views/livewire/frontend/products/index.blade.php ENDPATH**/ ?>