<div>
    


    <div class="py-3 py-md-5">
        <div class="container">
            <?php if(session()->has('message')): ?>
                <div class="alert alert-warning">
                    <?php echo e(session('message')); ?>

                </div>
            <?php endif; ?>
            <div class="row">
                <div class="py-3 py-md-5 bg-light">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-5 mt-3">
                                <div class="bg-white border">
                                    <?php if($product->productImages): ?>
                                        <img src="<?php echo e(asset($product->productImages[0]->image)); ?>" class="w-100"
                                            alt="Img">
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-7 mt-3">
                                <div class="product-view">
                                    <h4 class="product-name">
                                        <?php echo e($product->name); ?>


                                    </h4>
                                    <hr>
                                    <p class="product-path">
                                        Home / <?php echo e($category->name); ?> / <?php echo e($product->name); ?>

                                    </p>

                                    <div>
                                        <span class="selling-price">$<?php echo e($product->selling_price); ?></span>
                                        <span class="original-price">$<?php echo e($product->original_price); ?></span>
                                    </div>
                                    <div class="mt-2">
                                        <div class="input-group">
                                            <span class="btn btn1" wire:click="decrementQuantity"><i
                                                    class="fa fa-minus"></i></span>
                                            <input type="text" wire:model="countQuantity"
                                                value="<?php echo e($countQuantity); ?>" class="input-quantity" readonly />
                                            <span class="btn btn1"wire:click="incrementQuantity"><i
                                                    class="fa fa-plus"></i></span>
                                        </div>
                                    </div>
                                    <div class="pt-4 d-block">
                                        <?php if($product->productColors->count() > 0): ?>

                                            <?php if($product->productColors): ?>
                                                <?php $__currentLoopData = $product->ProductColors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productColor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <label class="colorSelectionLabel mx-3 p-2 text-light"
                                                        style="background-color: <?php echo e($productColor->color->code); ?>"
                                                        wire:click="colorSelected(<?php echo e($productColor->id); ?>)"><?php echo e($productColor->color->name); ?></label>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            <?php endif; ?>
                                            <?php if($prodColorSelectedQuantity <= 0): ?>
                                                <button class="btn  mx-1 label-stock bg-danger text-white">out of
                                                    Stock</button>
                                            <?php elseif($prodColorSelectedQuantity > 0): ?>
                                                <button class="btn  mx-1 label-stock bg-success text-white">In
                                                    Stock</button>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <?php if($product->quantity > 0): ?>
                                                <div>
                                                    <button class="btn  mx-1 label-stock bg-success text-white">In
                                                        Stock</button>
                                                </div>
                                            <?php else: ?>
                                                <div>
                                                    <button class="btn  mx-1 label-stock bg-danger text-white">out of
                                                        Stock</button>
                                                </div>
                                            <?php endif; ?>

                                        <?php endif; ?>

                                    </div>
                                    <div class="mt-2">
                                        <button type="button" wire:click='addToCart(<?php echo e($product->id); ?>)' class="btn btn1"> <i class="fa fa-shopping-cart"></i> Add To
                                            Cart</button>
                                        <button type="button" wire:click='addToWishList(<?php echo e($product->id); ?>)'
                                            class="btn btn1">
                                            <span wire:loading.remove>
                                                <i class="fa fa-heart"></i> Add To
                                                Wishlist</span>
                                            <span wire:loading wire:target="addToWishList">
                                                Adding...
                                            </span>
                                        </button>
                                    </div>
                                    <div class="mt-3">
                                        <h5 class="mb-0">Description</h5>
                                        <p>
                                            <?php echo e($product->small_description); ?> </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12 mt-3">
                                <div class="card">
                                    <div class="card-header bg-white">
                                        <h4>Description</h4>
                                    </div>
                                    <div class="card-body">
                                        <p>
                                            <?php echo e($product->long_description); ?> </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Program Files\Ampps\www\Laravel Projects\Livewire\eCom\eCom\resources\views/livewire/frontend/products/view.blade.php ENDPATH**/ ?>