<table class="table table-bordered table-striped">
    <thead>
        <tr>
            <th>
                ID
            </th>
            <th>
                Name
            </th>
            <th>
                Status
            </th>
            <th>
                Action
            </th>
        </tr>
    </thead>
    <tbody>
        <?php if(isset($categories)): ?>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php echo e($category->id); ?>

                    </td>
                    <td>
                        <?php echo e($category->name); ?>

                    </td>
                    <td>
                        <?php echo e($category->status); ?>

                    </td>
                    <td>
                        <a href="<?php echo e($category->id); ?>" class="btn btn-success">
                            Edit
                        </a>
                        <a  href="<?php echo e($category->id); ?>"class="btn btn-danger">
                            Delete
                        </a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

    </tbody>
</table>
<?php /**PATH C:\Program Files\Ampps\www\Laravel Projects\Livewire\eCom\eCom\resources\views/livewire/admin/category/category.blade.php ENDPATH**/ ?>