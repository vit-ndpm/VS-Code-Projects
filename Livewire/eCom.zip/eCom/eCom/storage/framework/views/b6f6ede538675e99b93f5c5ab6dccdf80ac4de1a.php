<div>
    
    <div  wire:ignore.self class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Delete Category</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <form wire:submit.prevent='destroyCategory'>
          <div class="modal-body">
            Are you Sure to Delete Category
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Yes,Delete</button>
          </div>
        </form>

        </div>
      </div>
    </div>
    
<table class="table table-bordered table-striped">
    <thead>
        <tr>
            <th>
                id
            </th>
            <th>
                Image
            </th>
            <th>
                name
            </th>
            <th>
                Description
            </th>
            <th>
                status
            </th>
            <th>
                Action
            </th>
        </tr>
    </thead>
    <tbody>
        <?php if(isset($categories)): ?>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
            
                <tr>
                    <td>
                        <?php echo e($category->id); ?>

                    </td>
                    <td>
                        <img src="<?php echo e(asset($category->image)); ?>" alt="">
                        
                    </td>
                    <td>
                        <?php echo e($category->name); ?>

                    </td>
                    <td>
                        <?php echo e($category->description); ?>

                    </td>
                    <td>
                        <?php echo e($category->status); ?>

                    </td>
                    <td>
                        <a class="btn btn-primary" href="<?php echo e(url('admin/category/'.$category->id.'/edit')); ?>">Edit</a> 
                        <a class="btn btn-danger" wire:click='deleteCategory(<?php echo e($category->id); ?>)' href="#" data-bs-toggle="modal" data-bs-target="#deleteModal">Delete</a> 
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        <?php endif; ?>
    </tbody>
</table>
<div>
    <?php echo e($categories->links()); ?>

</div>
</div>
<?php $__env->startPush('script'); ?>
    <script>
        window.addEventListener('close-modal', event=>{
            $('#deleteModal').modal('hide');
        });
    </script>
<?php $__env->stopPush(); ?><?php /**PATH C:\Program Files\Ampps\www\Laravel Projects\Livewire\eCom\eCom\resources\views/livewire/admin/category/category-componet.blade.php ENDPATH**/ ?>