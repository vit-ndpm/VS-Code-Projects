
<?php $__env->startSection('title', 'wishlist'); ?>
<?php $__env->startSection('content'); ?>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frondend.wishlist-show', [])->html();
} elseif ($_instance->childHasBeenRendered('Dj4dZGW')) {
    $componentId = $_instance->getRenderedChildComponentId('Dj4dZGW');
    $componentTag = $_instance->getRenderedChildComponentTagName('Dj4dZGW');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Dj4dZGW');
} else {
    $response = \Livewire\Livewire::mount('frondend.wishlist-show', []);
    $html = $response->html();
    $_instance->logRenderedChild('Dj4dZGW', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Program Files\Ampps\www\Laravel Projects\Livewire\eCom\eCom\resources\views/frontend/wishlist/index.blade.php ENDPATH**/ ?>