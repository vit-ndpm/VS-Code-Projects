<div>
    <div class="py-3 py-md-5 bg-light">
        <div class="container">

            <div class="row">
                <div class="col-md-12">
                    <div class="shopping-cart">

                        <div class="cart-header d-none d-sm-none d-mb-block d-lg-block">
                            <div class="row">
                                <div class="col-md-6">
                                    <h4>Products</h4>
                                </div>
                                <div class="col-md-3">
                                    <h4>Price</h4>
                                </div>

                                <div class="col-md-3">
                                    <h4>Remove</h4>
                                </div>
                            </div>
                        </div>
                        <?php $__empty_1 = true; $__currentLoopData = $wishlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wishlistItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php if($wishlistItem->product()): ?>
                                <div class="cart-item">
                                    <div class="row">
                                        <div class="col-md-6 my-auto">
                                            <a
                                                href="<?php echo e(url('collections/product/' . $wishlistItem->product->category->slug . '/' . $wishlistItem->product->slug)); ?>">
                                                <label class="product-name">
                                                    <img src="<?php echo e(asset($wishlistItem->product->productImages[0]->image)); ?>"
                                                        style="width: 50px; height: 50px"
                                                        alt="<?php echo e($wishlistItem->product->name); ?>">
                                                    <?php echo e($wishlistItem->product->name); ?>

                                                </label>
                                            </a>
                                        </div>
                                        <div class="col-md-3 my-auto">
                                            <label class="price">$ <?php echo e($wishlistItem->product->selling_price); ?> </label>
                                        </div>

                                        <div class="col-md-3 col-12 my-auto">
                                            <div class="remove">
                                                <button type="button"
                                                    wire:click="removeWishList(<?php echo e($wishlistItem->id); ?>)"
                                                    class="btn btn-danger btn-sm">
                                                    <span wire:loading.remove><i class="fa fa-trash"></i> Remove</span>
                                                    <span wire:loading wire:target='removeWishList'>
                                                        Removing...
                                                    </span>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <h4>No Item Added to Wishlist</h4>
                        <?php endif; ?>

                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
<?php /**PATH C:\Program Files\Ampps\www\Laravel Projects\Livewire\eCom\eCom\resources\views/livewire/frondend/wishlist-show.blade.php ENDPATH**/ ?>