
<?php $__env->startSection('title', 'wishlist'); ?>
<?php $__env->startSection('content'); ?>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.cart.cart-show', [])->html();
} elseif ($_instance->childHasBeenRendered('HsOttML')) {
    $componentId = $_instance->getRenderedChildComponentId('HsOttML');
    $componentTag = $_instance->getRenderedChildComponentTagName('HsOttML');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('HsOttML');
} else {
    $response = \Livewire\Livewire::mount('frontend.cart.cart-show', []);
    $html = $response->html();
    $_instance->logRenderedChild('HsOttML', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Program Files\Ampps\www\Laravel Projects\Livewire\eCom\eCom\resources\views/frontend/Cart/index.blade.php ENDPATH**/ ?>