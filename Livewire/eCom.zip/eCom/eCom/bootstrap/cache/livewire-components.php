<?php return array (
  'admin.brand.brand-compo' => 'App\\Http\\Livewire\\Admin\\Brand\\BrandCompo',
  'admin.category.category-componet' => 'App\\Http\\Livewire\\Admin\\Category\\CategoryComponet',
  'frondend.wishlist-show' => 'App\\Http\\Livewire\\Frondend\\WishlistShow',
  'frontend.cart.cart-count' => 'App\\Http\\Livewire\\Frontend\\Cart\\CartCount',
  'frontend.cart.cart-show' => 'App\\Http\\Livewire\\Frontend\\Cart\\CartShow',
  'frontend.checkout.checkout-show' => 'App\\Http\\Livewire\\Frontend\\Checkout\\CheckoutShow',
  'frontend.products.index' => 'App\\Http\\Livewire\\Frontend\\Products\\Index',
  'frontend.products.view' => 'App\\Http\\Livewire\\Frontend\\Products\\View',
  'frontend.wishlist.wishlist-count' => 'App\\Http\\Livewire\\Frontend\\Wishlist\\WishlistCount',
  'prod-color-qty' => 'App\\Http\\Livewire\\ProdColorQty',
);