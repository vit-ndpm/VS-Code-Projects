@extends('layouts.app')
@section('title', 'wishlist')
@section('content')
<livewire:frontend.cart.cart-show/>
@endsection