@extends('layouts.app')
@section('title', 'wishlist')
@section('content')
<livewire:frondend.wishlist-show>
@endsection